package monsterdungeon;

public class Game 
{
	Game()
	{
		Utility utility = new Utility();		
		World world = new World();
		PlayLoop();
	}
	void PlayLoop()
	{
		
	}
}
