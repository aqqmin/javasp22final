package monsterdungeon;

public class NonPlayer {

}
